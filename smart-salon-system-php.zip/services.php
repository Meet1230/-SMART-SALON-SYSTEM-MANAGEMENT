<?php
require_once __DIR__ . "/config.php";
require_role(['owner']);
$PAGE_TITLE = "Services";

$owner_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT id FROM salons WHERE owner_id = ? LIMIT 1");
$stmt->bind_param("i", $owner_id);
$stmt->execute();
$salon = $stmt->get_result()->fetch_assoc();
if (!$salon) {
    $_SESSION['flash_error'] = "Please create your salon profile first.";
    header("Location: /salon.php");
    exit();
}
$salon_id = (int)$salon['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create'])) {
        $name = trim($_POST['name'] ?? '');
        $duration = (int)($_POST['duration'] ?? 30);
        $price = (float)($_POST['price'] ?? 0);
        if ($name === '') {
            $_SESSION['flash_error'] = "Service name is required.";
        } else {
            $stmt = $conn->prepare("INSERT INTO services (salon_id, name, duration, price) VALUES (?,?,?,?)");
            $stmt->bind_param("isid", $salon_id, $name, $duration, $price);
            $stmt->execute();
            $_SESSION['flash_success'] = "Service added.";
        }
        header("Location: /services.php");
        exit();
    }
    if (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $stmt = $conn->prepare("DELETE FROM services WHERE id = ? AND salon_id = ?");
        $stmt->bind_param("ii", $id, $salon_id);
        $stmt->execute();
        $_SESSION['flash_success'] = "Service deleted.";
        header("Location: /services.php");
        exit();
    }
}

$stmt = $conn->prepare("SELECT * FROM services WHERE salon_id = ? ORDER BY name");
$stmt->bind_param("i", $salon_id);
$stmt->execute();
$services = $stmt->get_result();
?>
<?php include __DIR__ . "/partials/header.php"; ?>
<?php include __DIR__ . "/partials/flash.php"; ?>

<h2>Service Catalog</h2>

<h3>Add Service</h3>
<form method="post">
    <input type="hidden" name="create" value="1">
    <label>Service Name</label>
    <input type="text" name="name" required>
    <label>Duration (minutes)</label>
    <input type="number" name="duration" value="30" min="5">
    <label>Price (₹)</label>
    <input type="number" name="price" value="200" min="0" step="0.01">
    <button type="submit" class="btn btn-primary">Add</button>
</form>

<h3>Existing Services</h3>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Duration (min)</th>
            <th>Price (₹)</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($s = $services->fetch_assoc()): ?>
            <tr>
                <td><?php echo (int)$s['id']; ?></td>
                <td><?php echo htmlspecialchars($s['name']); ?></td>
                <td><?php echo (int)$s['duration']; ?></td>
                <td><?php echo number_format($s['price'], 2); ?></td>
                <td>
                    <form method="post" style="display:inline;" onsubmit="return confirm('Delete this service?');">
                        <input type="hidden" name="id" value="<?php echo (int)$s['id']; ?>">
                        <button type="submit" name="delete" value="1" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include __DIR__ . "/partials/footer.php"; ?>
