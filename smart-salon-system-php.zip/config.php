<?php
// Smart Salon System - Global Config & Helpers

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "salon_journal";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

session_start();

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function current_user_role() {
    return $_SESSION['role'] ?? null;
}

function require_login() {
    if (!is_logged_in()) {
        header("Location: /auth/login.php");
        exit();
    }
}

function require_role($roles = []) {
    require_login();
    if (!in_array(current_user_role(), $roles)) {
        http_response_code(403);
        echo "Access denied";
        exit();
    }
}

/**
 * Simple ETA calculator (placeholder for AI microservice)
 * In your report, ETA is predicted by a Python/ML service.
 * For demo, we approximate ETA using queue length and service duration.
 */
function calculate_simple_eta($service_duration_minutes, $queue_length) {
    $now = new DateTime();
    $offsetMinutes = max(0, ($queue_length) * (int)$service_duration_minutes);
    $now->modify("+$offsetMinutes minutes");
    return $now->format("Y-m-d H:i:s");
}

/**
 * Placeholder for Gemini / AI strategy advice.
 * In real deployment, you would call an external API here.
 */
function get_ai_strategy_advice($metrics = []) {
    $totalBookings = $metrics['total_bookings'] ?? 0;
    $avgWait = $metrics['avg_wait'] ?? 0;
    $util = $metrics['staff_utilization'] ?? 0;

    $lines = [];
    $lines[] = "1. Focus on peak-hour optimization. Consider adding more staff between 6–9 PM if bookings stay high.";
    if ($avgWait > 20) {
        $lines[] = "2. Average wait time is on the higher side. Try spreading appointments more evenly and reduce overbooking.";
    } else {
        $lines[] = "2. Your average wait time is under control. Highlight this as a unique selling point to customers.";
    }
    if ($util < 60) {
        $lines[] = "3. Staff utilization seems low. Revisit staff scheduling and reduce idle gaps between services.";
    } else {
        $lines[] = "3. Staff utilization is healthy. Consider introducing premium add-on services to increase revenue per visit.";
    }
    $lines[] = "4. Encourage customers to rate services to better align staff training and promotions with real feedback.";
    return implode(\"\\n\", $lines);
}
?>
