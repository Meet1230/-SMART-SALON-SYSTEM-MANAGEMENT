<?php
require_once __DIR__ . "/config.php";
require_role(['owner']);
$PAGE_TITLE = "Bookings & Queue";

$owner_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT id, name FROM salons WHERE owner_id = ? LIMIT 1");
$stmt->bind_param("i", $owner_id);
$stmt->execute();
$salon = $stmt->get_result()->fetch_assoc();
if (!$salon) {
    $_SESSION['flash_error'] = "Please create your salon profile first.";
    header("Location: /salon.php");
    exit();
}
$salon_id = (int)$salon['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_queue'])) {
    $queue_id = (int)$_POST['queue_id'];
    $status = $_POST['status'] ?? 'waiting';
    if (!in_array($status, ['waiting','in_progress','done'])) {
        $status = 'waiting';
    }
    $stmt = $conn->prepare("UPDATE queue SET current_status = ?, last_updated = NOW() WHERE id = ?");
    $stmt->bind_param("si", $status, $queue_id);
    $stmt->execute();
    $_SESSION['flash_success'] = "Queue updated.";
    header("Location: /bookings_owner.php");
    exit();
}

$stmt = $conn->prepare("
    SELECT q.id AS queue_id, q.position, q.current_status,
           b.id AS booking_id, b.date_time, b.predicted_eta, b.status AS booking_status,
           u.name AS customer_name, sv.name AS service_name
    FROM queue q
    JOIN bookings b ON q.booking_id = b.id
    JOIN users u ON b.user_id = u.id
    JOIN services sv ON b.service_id = sv.id
    WHERE b.salon_id = ?
    ORDER BY q.position ASC
");
$stmt->bind_param("i", $salon_id);
$stmt->execute();
$queue_rs = $stmt->get_result();

$stmt = $conn->prepare("
    SELECT b.*, u.name AS customer_name, sv.name AS service_name
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN services sv ON b.service_id = sv.id
    WHERE b.salon_id = ?
    ORDER BY b.date_time DESC
    LIMIT 50
");
$stmt->bind_param("i", $salon_id);
$stmt->execute();
$bookings_rs = $stmt->get_result();
?>
<?php include __DIR__ . "/partials/header.php"; ?>
<?php include __DIR__ . "/partials/flash.php"; ?>

<h2>Bookings & Live Queue</h2>
<p>Salon: <strong><?php echo htmlspecialchars($salon['name']); ?></strong></p>

<h3>Live Queue</h3>
<table>
    <thead>
        <tr>
            <th>Pos</th>
            <th>Customer</th>
            <th>Service</th>
            <th>Booked At</th>
            <th>ETA</th>
            <th>Status</th>
            <th>Update</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($q = $queue_rs->fetch_assoc()): ?>
            <tr>
                <td><?php echo (int)$q['position']; ?></td>
                <td><?php echo htmlspecialchars($q['customer_name']); ?></td>
                <td><?php echo htmlspecialchars($q['service_name']); ?></td>
                <td><?php echo htmlspecialchars($q['date_time']); ?></td>
                <td><?php echo htmlspecialchars($q['predicted_eta']); ?></td>
                <td><?php echo htmlspecialchars($q['current_status']); ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="queue_id" value="<?php echo (int)$q['queue_id']; ?>">
                        <select name="status">
                            <option value="waiting" <?php if ($q['current_status']==='waiting') echo 'selected'; ?>>waiting</option>
                            <option value="in_progress" <?php if ($q['current_status']==='in_progress') echo 'selected'; ?>>in progress</option>
                            <option value="done" <?php if ($q['current_status']==='done') echo 'selected'; ?>>done</option>
                        </select>
                        <button type="submit" name="update_queue" value="1" class="btn btn-secondary">Save</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<h3>Recent Bookings</h3>
<table>
    <thead>
        <tr>
            <th>Customer</th>
            <th>Service</th>
            <th>Date & Time</th>
            <th>Status</th>
            <th>ETA</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($b = $bookings_rs->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($b['customer_name']); ?></td>
                <td><?php echo htmlspecialchars($b['service_name']); ?></td>
                <td><?php echo htmlspecialchars($b['date_time']); ?></td>
                <td><?php echo htmlspecialchars($b['status']); ?></td>
                <td><?php echo htmlspecialchars($b['predicted_eta']); ?></td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include __DIR__ . "/partials/footer.php"; ?>
