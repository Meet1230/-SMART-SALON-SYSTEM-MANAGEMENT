<?php
require_once __DIR__ . "/../config.php";
if (is_logged_in()) {
    header("Location: /index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $_SESSION['flash_error'] = "Email and password are required.";
    } else {
        $stmt = $conn->prepare("SELECT id, name, email, password, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['flash_success'] = "Welcome back, " . $user['name'];
            header("Location: /index.php");
            exit();
        } else {
            $_SESSION['flash_error'] = "Invalid login credentials.";
        }
    }
}

$PAGE_TITLE = "Login";
?>
<?php include __DIR__ . "/../partials/header.php"; ?>
<?php include __DIR__ . "/../partials/flash.php"; ?>

<h2>Login</h2>
<form method="post">
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Password</label>
    <input type="password" name="password" required>
    <button type="submit" class="btn btn-primary">Login</button>
</form>

<p>New user? <a href="/auth/register.php">Create an account</a>.</p>

<?php include __DIR__ . "/../partials/footer.php"; ?>
