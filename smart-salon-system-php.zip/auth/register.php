<?php
require_once __DIR__ . "/../config.php";
if (is_logged_in()) {
    header("Location: /index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? 'customer';

    if ($name === '' || $email === '' || $password === '') {
        $_SESSION['flash_error'] = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['flash_error'] = "Invalid email address.";
    } elseif ($password !== $confirm) {
        $_SESSION['flash_error'] = "Passwords do not match.";
    } elseif (!in_array($role, ['customer','owner'])) {
        $_SESSION['flash_error'] = "Invalid role.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $_SESSION['flash_error'] = "Email already exists.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)");
            $stmt->bind_param("ssss", $name, $email, $hash, $role);
            $stmt->execute();
            $_SESSION['flash_success'] = "Registration successful. Please login.";
            header("Location: /auth/login.php");
            exit();
        }
    }
}

$PAGE_TITLE = "Register";
?>
<?php include __DIR__ . "/../partials/header.php"; ?>
<?php include __DIR__ . "/../partials/flash.php"; ?>

<h2>Create Account</h2>
<form method="post">
    <label>Full Name</label>
    <input type="text" name="name" required>
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Password</label>
    <input type="password" name="password" required>
    <label>Confirm Password</label>
    <input type="password" name="confirm_password" required>
    <label>Role</label>
    <select name="role">
        <option value="customer">Customer</option>
        <option value="owner">Salon Owner</option>
    </select>
    <button type="submit" class="btn btn-primary">Register</button>
</form>

<p>Already have an account? <a href="/auth/login.php">Login here</a>.</p>

<?php include __DIR__ . "/../partials/footer.php"; ?>
