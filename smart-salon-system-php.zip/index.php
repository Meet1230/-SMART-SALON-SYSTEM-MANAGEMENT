<?php
require_once __DIR__ . "/config.php";
$role = current_user_role();
$PAGE_TITLE = "Dashboard";

if (!is_logged_in()) {
    $PAGE_TITLE = "Welcome";
}
?>
<?php include __DIR__ . "/partials/header.php"; ?>
<?php include __DIR__ . "/partials/flash.php"; ?>

<?php if (!is_logged_in()): ?>
    <h2>Welcome to Smart Salon System</h2>
    <p>
        This platform lets customers book salon services online and track their queue status,
        while salon owners manage bookings, services and live queues from a single dashboard.
    </p>
    <p>
        <a class="btn btn-primary" href="/auth/register.php">Get Started – Register</a>
        <a class="btn btn-secondary" href="/auth/login.php">Login</a>
    </p>
<?php elseif ($role === 'owner'): ?>
    <h2>Owner Dashboard</h2>
    <?php
    // Quick stats for owner
    $owner_id = $_SESSION['user_id'];

    // Salon id for this owner
    $salon_id = null;
    $stmt = $conn->prepare("SELECT id, name FROM salons WHERE owner_id = ? LIMIT 1");
    $stmt->bind_param("i", $owner_id);
    $stmt->execute();
    $salon = $stmt->get_result()->fetch_assoc();
    if ($salon) {
        $salon_id = (int)$salon['id'];
    }

    $stats = [
        'services' => 0,
        'today_bookings' => 0,
        'active_queue' => 0,
        'revenue_today' => 0.0
    ];

    if ($salon_id) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM services WHERE salon_id = ?");
        $stmt->bind_param("i", $salon_id);
        $stmt->execute();
        $stats['services'] = (int)$stmt->get_result()->fetch_assoc()['c'];

        $today = date("Y-m-d");
        $stmt = $conn->prepare("SELECT COUNT(*) AS c, COALESCE(SUM(price),0) AS rev 
                                FROM bookings b
                                JOIN services s ON b.service_id = s.id
                                WHERE b.salon_id = ? AND DATE(b.date_time) = ?");
        $stmt->bind_param("is", $salon_id, $today);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stats['today_bookings'] = (int)$row['c'];
        $stats['revenue_today'] = (float)$row['rev'];

        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM queue q 
                                JOIN bookings b ON q.booking_id = b.id
                                WHERE b.salon_id = ? AND q.current_status IN ('waiting','in_progress')");
        $stmt->bind_param("i", $salon_id);
        $stmt->execute();
        $stats['active_queue'] = (int)$stmt->get_result()->fetch_assoc()['c'];
    }
    ?>

    <div class="flex">
        <div class="card">
            <h3>My Salon</h3>
            <p><?php echo $salon ? htmlspecialchars($salon['name']) : "No salon profile yet"; ?></p>
            <a class="btn btn-primary" href="/salon.php">Manage Salon</a>
        </div>
        <div class="card">
            <h3>Services</h3>
            <p><?php echo $stats['services']; ?> services configured</p>
            <a class="btn btn-primary" href="/services.php">Manage Services</a>
        </div>
        <div class="card">
            <h3>Today's Bookings</h3>
            <p><?php echo $stats['today_bookings']; ?> bookings</p>
        </div>
        <div class="card">
            <h3>Active Queue</h3>
            <p><?php echo $stats['active_queue']; ?> customers waiting / in progress</p>
        </div>
        <div class="card">
            <h3>Today's Revenue</h3>
            <p>₹ <?php echo number_format($stats['revenue_today'], 2); ?></p>
        </div>
    </div>

    <h3>Quick Queue View</h3>
    <?php if ($salon_id): ?>
        <?php
        $stmt = $conn->prepare("
            SELECT q.id AS queue_id, q.position, q.current_status, 
                   b.id AS booking_id, b.date_time, b.predicted_eta,
                   u.name AS customer_name, s.name AS service_name
            FROM queue q
            JOIN bookings b ON q.booking_id = b.id
            JOIN users u ON b.user_id = u.id
            JOIN services s ON b.service_id = s.id
            WHERE b.salon_id = ?
            ORDER BY q.position ASC
        ");
        $stmt->bind_param("i", $salon_id);
        $stmt->execute();
        $queue_rs = $stmt->get_result();
        ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Customer</th>
                    <th>Service</th>
                    <th>Booking Time</th>
                    <th>ETA</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($q = $queue_rs->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo (int)$q['position']; ?></td>
                        <td><?php echo htmlspecialchars($q['customer_name']); ?></td>
                        <td><?php echo htmlspecialchars($q['service_name']); ?></td>
                        <td><?php echo htmlspecialchars($q['date_time']); ?></td>
                        <td><?php echo htmlspecialchars($q['predicted_eta']); ?></td>
                        <td>
                            <span class="badge <?php
                                if ($q['current_status']==='waiting') echo 'badge-warning';
                                elseif ($q['current_status']==='in_progress') echo 'badge-info';
                                else echo 'badge-success';
                            ?>"><?php echo htmlspecialchars($q['current_status']); ?></span>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No salon profile found. Please create one.</p>
    <?php endif; ?>

<?php else: ?>
    <h2>Hi, <?php echo htmlspecialchars($_SESSION['name']); ?> 👋</h2>
    <p>
        You can book your next salon service online and avoid long waiting times.
        Track your live queue position and ETA anytime.
    </p>
    <p>
        <a href="/bookings.php" class="btn btn-primary">Book an Appointment</a>
        <a href="/queue.php" class="btn btn-secondary">View My Queue</a>
    </p>
<?php endif; ?>

<?php include __DIR__ . "/partials/footer.php"; ?>
