<?php
if (!isset($PAGE_TITLE)) {
    $PAGE_TITLE = "Smart Salon System";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($PAGE_TITLE); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Simple styling, you can replace with Bootstrap/Tailwind -->
    <style>
        :root {
            --primary: #e91e63;
            --primary-dark: #ad1457;
            --bg: #f7f7f9;
        }
        * { box-sizing:border-box; }
        body { margin:0; font-family:Arial, sans-serif; background:var(--bg); }
        header { background:var(--primary); color:#fff; padding:10px 20px; }
        header .brand { font-weight:bold; font-size:20px; }
        nav a { color:#fff; text-decoration:none; margin-right:10px; }
        nav a:hover { text-decoration:underline; }
        .container { max-width:1100px; margin:0 auto; padding:20px; background:#fff; min-height:80vh; }
        .btn { display:inline-block; padding:6px 12px; border-radius:4px; border:none; cursor:pointer; text-decoration:none; font-size:14px; }
        .btn-primary { background:var(--primary); color:#fff; }
        .btn-secondary { background:#607d8b; color:#fff; }
        .btn-danger { background:#f44336; color:#fff; }
        table { width:100%; border-collapse:collapse; margin-top:10px; }
        th, td { padding:8px; border:1px solid #ddd; text-align:left; font-size:14px; }
        th { background:#f1f1f1; }
        input[type=text], input[type=password], input[type=email], input[type=datetime-local], select, textarea, input[type=number] {
            width:100%; padding:6px; margin-bottom:8px; border:1px solid #ccc; border-radius:3px;
        }
        .flex { display:flex; gap:10px; flex-wrap:wrap; }
        .card { border:1px solid #eee; border-radius:6px; padding:10px; background:#fafafa; flex:1; min-width:180px; }
        footer { text-align:center; padding:8px; font-size:12px; color:#777; }
        .text-right { text-align:right; }
        .badge { display:inline-block; padding:2px 6px; border-radius:10px; font-size:11px; background:#eee; }
        .badge-success { background:#c8e6c9; }
        .badge-warning { background:#ffe0b2; }
        .badge-info { background:#bbdefb; }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
</head>
<body>
<header>
    <div style="display:flex;justify-content:space-between;align-items:center;">
        <div class="brand">Smart Salon System</div>
        <nav>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['role'] === 'owner'): ?>
                    <a href="/index.php">Dashboard</a>
                    <a href="/salon.php">My Salon</a>
                    <a href="/services.php">Services</a>
                    <a href="/bookings_owner.php">Bookings & Queue</a>
                    <a href="/analytics.php">Analytics</a>
                <?php else: ?>
                    <a href="/index.php">Home</a>
                    <a href="/bookings.php">Book Slot</a>
                    <a href="/queue.php">My Queue</a>
                <?php endif; ?>
                <span>| <?php echo htmlspecialchars($_SESSION['name'] ?? ''); ?> (<?php echo htmlspecialchars($_SESSION['role']); ?>)</span>
                <a href="/auth/logout.php">Logout</a>
            <?php else: ?>
                <a href="/auth/login.php">Login</a>
                <a href="/auth/register.php">Register</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<div class="container">
