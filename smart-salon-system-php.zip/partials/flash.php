<?php
if (!empty($_SESSION['flash_success'])) {
    echo '<div style="padding:8px 10px;margin-bottom:10px;border-radius:3px;background:#d4edda;color:#155724;">' . htmlspecialchars($_SESSION['flash_success']) . '</div>';
    unset($_SESSION['flash_success']);
}
if (!empty($_SESSION['flash_error'])) {
    echo '<div style="padding:8px 10px;margin-bottom:10px;border-radius:3px;background:#f8d7da;color:#721c24;">' . htmlspecialchars($_SESSION['flash_error']) . '</div>';
    unset($_SESSION['flash_error']);
}
?>
