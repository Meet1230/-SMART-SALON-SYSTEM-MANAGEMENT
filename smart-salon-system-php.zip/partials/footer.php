</div>
<footer>
    &copy; <?php echo date("Y"); ?> Smart Salon Booking & Queue Management System
</footer>
</body>
</html>
