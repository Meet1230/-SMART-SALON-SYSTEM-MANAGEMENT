<?php
require_once __DIR__ . "/config.php";
require_role(['owner']);
$PAGE_TITLE = "My Salon";

$owner_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM salons WHERE owner_id = ? LIMIT 1");
$stmt->bind_param("i", $owner_id);
$stmt->execute();
$salon = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $timing = trim($_POST['timing'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if ($name === '') {
        $_SESSION['flash_error'] = "Salon name is required.";
    } else {
        if ($salon) {
            $stmt = $conn->prepare("UPDATE salons SET name=?, location=?, timing=?, description=? WHERE id=? AND owner_id=?");
            $stmt->bind_param("ssssii", $name, $location, $timing, $description, $salon['id'], $owner_id);
            $stmt->execute();
            $_SESSION['flash_success'] = "Salon profile updated.";
        } else {
            $stmt = $conn->prepare("INSERT INTO salons (owner_id, name, location, timing, description) VALUES (?,?,?,?,?)");
            $stmt->bind_param("issss", $owner_id, $name, $location, $timing, $description);
            $stmt->execute();
            $_SESSION['flash_success'] = "Salon profile created.";
        }
        header("Location: /salon.php");
        exit();
    }
}

$stmt = $conn->prepare("SELECT * FROM salons WHERE owner_id = ? LIMIT 1");
$stmt->bind_param("i", $owner_id);
$stmt->execute();
$salon = $stmt->get_result()->fetch_assoc();
?>
<?php include __DIR__ . "/partials/header.php"; ?>
<?php include __DIR__ . "/partials/flash.php"; ?>

<h2>My Salon Profile</h2>
<form method="post">
    <label>Salon Name</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($salon['name'] ?? ''); ?>" required>
    <label>Location</label>
    <input type="text" name="location" value="<?php echo htmlspecialchars($salon['location'] ?? ''); ?>">
    <label>Working Hours</label>
    <input type="text" name="timing" placeholder="e.g. 10:00 AM - 9:00 PM" value="<?php echo htmlspecialchars($salon['timing'] ?? ''); ?>">
    <label>Description</label>
    <textarea name="description" rows="3"><?php echo htmlspecialchars($salon['description'] ?? ''); ?></textarea>
    <button type="submit" class="btn btn-primary">Save</button>
</form>

<?php include __DIR__ . "/partials/footer.php"; ?>
