# Smart Salon Booking & Queue Management System (with AI ETA placeholder)

This repository contains a simplified implementation of the **Smart Salon Booking & Queue Management System** described in the project report.

It is built using:

- PHP (server-side logic)
- MySQL (database)
- HTML, CSS, JavaScript (frontend)
- Chart.js (basic analytics)
- A placeholder function for **AI-powered ETA prediction** (can be replaced by a real Python/ML microservice later).

> Note: For academic/viva purposes this project demonstrates the core flow – online booking, queue management and ETA calculation.  
> Integration with Gemini API or a real Python model can be added on top of this codebase.

## 1. Features

### Customer
- Register & Login
- View salons
- Book an appointment (select salon, service, date & time)
- Automatic queue position and ETA (simple formula)
- View live queue status (`queue.php`)

### Salon Owner
- Register as **owner**
- Create & manage **salon profile**
- Create & manage **services** (name, duration, price)
- View **bookings & live queue** (`bookings_owner.php`)
- Update queue status (waiting / in progress / done)
- View **analytics** (last 7 days bookings & revenue)
- See **AI strategy suggestions** (generated locally in PHP as a placeholder)

## 2. Setup (XAMPP)

1. Copy the folder to your web root, for example:

   ```bash
   C:\xampp\htdocs\smart_salon
   ```

2. Create the database:

   - Open **phpMyAdmin**
   - Import `database.sql`
   - Ensure the database name is `salon_journal` (or change it in `config.php`)

3. Start **Apache** and **MySQL** in XAMPP.

4. Open in browser:

   ```text
   http://localhost/smart_salon/auth/register.php
   ```

5. Create:
   - One **owner** account for salon owner
   - One **customer** account for testing bookings

## 3. File Map (Important Files)

- `config.php` – DB connection, session, role helpers, ETA + AI placeholder
- `partials/header.php`, `partials/footer.php`, `partials/flash.php` – layout
- `/auth/login.php`, `/auth/register.php`, `/auth/logout.php`
- `index.php` – home / dashboard
- `salon.php` – salon profile (owner)
- `services.php` – service catalog (owner)
- `bookings.php` – booking screen (customer)
- `queue.php` – customer live queue
- `bookings_owner.php` – owner view of queue & bookings
- `analytics.php` – chart + AI advice demo

## 4. GitHub

After extracting this project into a folder, run:

```bash
git init
git add .
git commit -m "Initial commit - Smart Salon Booking System"
git branch -M main
git remote add origin https://github.com/your-username/smart-salon-system.git
git push -u origin main
```

You can extend this project by:

- Replacing `calculate_simple_eta()` with a real Python/Flask microservice call
- Replacing `get_ai_strategy_advice()` with a Gemini API call
- Adding Tailwind/Bootstrap, Dompdf, PhpSpreadsheet, etc., as per your report.
