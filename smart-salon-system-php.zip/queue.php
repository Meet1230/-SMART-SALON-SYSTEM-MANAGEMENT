<?php
require_once __DIR__ . "/config.php";
require_role(['customer']);
$PAGE_TITLE = "My Queue";

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT q.position, q.current_status, b.date_time, b.predicted_eta,
           s.name AS salon_name, sv.name AS service_name
    FROM bookings b
    JOIN queue q ON q.booking_id = b.id
    JOIN salons s ON b.salon_id = s.id
    JOIN services sv ON b.service_id = sv.id
    WHERE b.user_id = ? AND q.current_status IN ('waiting','in_progress')
    ORDER BY q.position ASC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$active = $stmt->get_result();

$has_active = $active->num_rows > 0;
?>
<?php include __DIR__ . "/partials/header.php"; ?>
<?php include __DIR__ . "/partials/flash.php"; ?>

<h2>My Live Queue Status</h2>

<?php if (!$has_active): ?>
    <p>You are currently not in any active queue.</p>
    <p><a href="/bookings.php" class="btn btn-primary">Book a new appointment</a></p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Salon</th>
                <th>Service</th>
                <th>Queue #</th>
                <th>Status</th>
                <th>Booked At</th>
                <th>ETA</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($q = $active->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($q['salon_name']); ?></td>
                    <td><?php echo htmlspecialchars($q['service_name']); ?></td>
                    <td><?php echo (int)$q['position']; ?></td>
                    <td><?php echo htmlspecialchars($q['current_status']); ?></td>
                    <td><?php echo htmlspecialchars($q['date_time']); ?></td>
                    <td><?php echo htmlspecialchars($q['predicted_eta']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php include __DIR__ . "/partials/footer.php"; ?>
