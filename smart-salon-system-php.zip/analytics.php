<?php
require_once __DIR__ . "/config.php";
require_role(['owner']);
$PAGE_TITLE = "Analytics & AI Advice";

$owner_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT id, name FROM salons WHERE owner_id = ? LIMIT 1");
$stmt->bind_param("i", $owner_id);
$stmt->execute();
$salon = $stmt->get_result()->fetch_assoc();
if (!$salon) {
    $_SESSION['flash_error'] = "Please create your salon profile first.";
    header("Location: /salon.php");
    exit();
}
$salon_id = (int)$salon['id'];

// simple analytics: last 7 days bookings per day & revenue
$stmt = $conn->prepare("
    SELECT DATE(date_time) AS day,
           COUNT(*) AS bookings,
           COALESCE(SUM(s.price),0) AS revenue
    FROM bookings b
    JOIN services s ON b.service_id = s.id
    WHERE b.salon_id = ?
      AND DATE(date_time) >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
    GROUP BY DATE(date_time)
    ORDER BY day
");
$stmt->bind_param("i", $salon_id);
$stmt->execute();
$rs = $stmt->get_result();
$days = [];
$bookings = [];
$revenue = [];
while ($row = $rs->fetch_assoc()) {
    $days[] = $row['day'];
    $bookings[] = (int)$row['bookings'];
    $revenue[] = (float)$row['revenue'];
}

$totalBookings = array_sum($bookings);
$avgWait = 15; // static demo value, could be computed from data
$staffUtil = 70; // demo value

$metrics = [
    'total_bookings' => $totalBookings,
    'avg_wait' => $avgWait,
    'staff_utilization' => $staffUtil
];
$advice = get_ai_strategy_advice($metrics);

?>
<?php include __DIR__ . "/partials/header.php"; ?>
<?php include __DIR__ . "/partials/flash.php"; ?>

<h2>Analytics & AI Strategy Advice</h2>
<p>Salon: <strong><?php echo htmlspecialchars($salon['name']); ?></strong></p>

<div style="max-width:700px;">
    <canvas id="bookingsChart"></canvas>
</div>

<script>
const ctx = document.getElementById('bookingsChart').getContext('2d');
const chart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($days); ?>,
        datasets: [
            {
                label: 'Bookings',
                data: <?php echo json_encode($bookings); ?>,
            },
            {
                label: 'Revenue (₹)',
                data: <?php echo json_encode($revenue); ?>,
            }
        ]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

<h3>AI Strategy Suggestions (Demo)</h3>
<pre style="background:#f5f5f5;padding:10px;border-radius:4px;white-space:pre-wrap;"><?php echo htmlspecialchars($advice); ?></pre>

<?php include __DIR__ . "/partials/footer.php"; ?>
