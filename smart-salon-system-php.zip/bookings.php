<?php
require_once __DIR__ . "/config.php";
require_role(['customer']);
$PAGE_TITLE = "Book Appointment";

$user_id = $_SESSION['user_id'];

// list all salons + services
$salons_rs = $conn->query("SELECT s.id, s.name, s.location FROM salons s ORDER BY s.name");

$selected_salon_id = isset($_GET['salon_id']) ? (int)$_GET['salon_id'] : 0;
if ($selected_salon_id <= 0 && $salons_rs->num_rows > 0) {
    $first = $salons_rs->fetch_assoc();
    $selected_salon_id = (int)$first['id'];
    // re-run query because we consumed one row
    $salons_rs = $conn->query("SELECT s.id, s.name, s.location FROM salons s ORDER BY s.name");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $salon_id = (int)($_POST['salon_id'] ?? 0);
    $service_id = (int)($_POST['service_id'] ?? 0);
    $date_time = $_POST['date_time'] ?? '';

    if ($salon_id <= 0 || $service_id <= 0 || $date_time === '') {
        $_SESSION['flash_error'] = "All fields are required.";
    } else {
        // fetch service for duration + price
        $stmt = $conn->prepare("SELECT duration FROM services WHERE id = ? AND salon_id = ?");
        $stmt->bind_param("ii", $service_id, $salon_id);
        $stmt->execute();
        $service = $stmt->get_result()->fetch_assoc();
        if (!$service) {
            $_SESSION['flash_error'] = "Invalid service.";
        } else {
            // find current queue length for salon at that moment
            $stmt = $conn->prepare("
                SELECT COUNT(*) AS c
                FROM queue q
                JOIN bookings b ON q.booking_id = b.id
                WHERE b.salon_id = ? AND q.current_status IN ('waiting','in_progress')
            ");
            $stmt->bind_param("i", $salon_id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $queue_length = (int)$row['c'];

            $eta = calculate_simple_eta($service['duration'], $queue_length);

            // create booking
            $status = 'confirmed';
            $stmt = $conn->prepare("INSERT INTO bookings (user_id, salon_id, service_id, date_time, status, predicted_eta) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param("iiisss", $user_id, $salon_id, $service_id, $date_time, $status, $eta);
            $stmt->execute();
            $booking_id = $stmt->insert_id;

            // insert into queue
            $position = $queue_length + 1;
            $qStatus = 'waiting';
            $stmt = $conn->prepare("INSERT INTO queue (booking_id, position, current_status) VALUES (?,?,?)");
            $stmt->bind_param("iis", $booking_id, $position, $qStatus);
            $stmt->execute();

            $_SESSION['flash_success'] = "Booking confirmed! Your queue position is #$position. ETA: $eta";
            header("Location: /queue.php");
            exit();
        }
    }
}

$stmt = $conn->prepare("SELECT * FROM services WHERE salon_id = ? ORDER BY name");
$stmt->bind_param("i", $selected_salon_id);
$stmt->execute();
$services_rs = $stmt->get_result();

// my bookings
$stmt = $conn->prepare("
    SELECT b.*, s.name AS salon_name, sv.name AS service_name, q.position, q.current_status
    FROM bookings b
    JOIN salons s ON b.salon_id = s.id
    JOIN services sv ON b.service_id = sv.id
    LEFT JOIN queue q ON q.booking_id = b.id
    WHERE b.user_id = ?
    ORDER BY b.date_time DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$my_bookings = $stmt->get_result();
?>
<?php include __DIR__ . "/partials/header.php"; ?>
<?php include __DIR__ . "/partials/flash.php"; ?>

<h2>Book an Appointment</h2>

<form method="get">
    <label>Select Salon</label>
    <select name="salon_id" onchange="this.form.submit()">
        <?php while ($s = $salons_rs->fetch_assoc()): ?>
            <option value="<?php echo (int)$s['id']; ?>" <?php if ($selected_salon_id == $s['id']) echo 'selected'; ?>>
                <?php echo htmlspecialchars($s['name'] . " - " . $s['location']); ?>
            </option>
        <?php endwhile; ?>
    </select>
    <noscript><button type="submit" class="btn btn-secondary">Change</button></noscript>
</form>

<form method="post">
    <input type="hidden" name="salon_id" value="<?php echo (int)$selected_salon_id; ?>">
    <label>Service</label>
    <select name="service_id" required>
        <option value="">Select service</option>
        <?php while ($sv = $services_rs->fetch_assoc()): ?>
            <option value="<?php echo (int)$sv['id']; ?>">
                <?php echo htmlspecialchars($sv['name']); ?> (<?php echo (int)$sv['duration']; ?> min)
            </option>
        <?php endwhile; ?>
    </select>
    <label>Preferred Date & Time</label>
    <input type="datetime-local" name="date_time" required>
    <button type="submit" class="btn btn-primary">Confirm Booking</button>
</form>

<h3>My Recent Bookings</h3>
<table>
    <thead>
        <tr>
            <th>Salon</th>
            <th>Service</th>
            <th>Date & Time</th>
            <th>Status</th>
            <th>Queue #</th>
            <th>ETA</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($b = $my_bookings->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($b['salon_name']); ?></td>
                <td><?php echo htmlspecialchars($b['service_name']); ?></td>
                <td><?php echo htmlspecialchars($b['date_time']); ?></td>
                <td><?php echo htmlspecialchars($b['status']); ?></td>
                <td><?php echo $b['position'] ? (int)$b['position'] : '-'; ?></td>
                <td><?php echo htmlspecialchars($b['predicted_eta']); ?></td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include __DIR__ . "/partials/footer.php"; ?>
